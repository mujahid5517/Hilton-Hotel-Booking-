# HotelBookingSystem
This is a group project by CS students to implement JavaFX for Hotel booking systems 
